const Config = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  USER_TOKEN_KEY: 'token',
};

export default Config;
